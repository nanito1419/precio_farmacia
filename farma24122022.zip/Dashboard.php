<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>SOCOR FARMA v1.0</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
	<link rel="stylesheet" type="text/css" href="estilos/22.css">
	<link rel="shortcut icon" href="images/48855.png">
</head>
<body>

  <?php
    session_start();
    if (!isset($_SESSION['login'])) {
      header("location:index.php");
    }

  ?>
      <nav class="navbar navbar-fixed-top navbar-dark bg-dark ">
    <a class="navbar-brand" href="#">
      <img src="images/FVP1 SINF.png" width="90" height="55" class="d-inline-block align-top" alt="">
      <img src="images/socor.jpg" width="250" height="55" class="d-inline-block align-top" alt="">
      
    </a>
      <ul class="nav navbar-nav navbar-right">
         <a href="cierre.php"><button class="btn btn-danger">Cerrar sesion</button></a>
     </ul>
   </nav>

<br>
<br>
<div>
	<div class="container">
	  <div class="row">
		<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8" id="hola">
				<br><br>
				<div class="form-group">
                  <label class="col-form-label col-form-label-lg" for="inputLarge"><h3 id="text1">Buscar Medicamento:</h3></label><?php if(isset($_SESSION['t'])) { echo $_SESSION['t'];}?>
                  <form action="buscar_medicamento.php" method="GET">
                  <input class="form-control form-control-lg" minlength="4" type="text" placeholder="Introduzca el Medicamento a buscar!!" id="inputLarge" name="nombre_medicamento">
                  <input class="form-control form-control-lg" type="text" placeholder="Introduzca la cantidad o volumen del medicamento" id="inputLarge" name="cantidad">
                  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="hola">
                  <label class="col-form-label col-form-label-lg" for="inputLarge"><h4 id="text1">Selecciona la unidad de medicion O (ubicacion)</h4>
                  <div class="form-check">
        <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
        <label class="form-check-label" for="gridRadios2" id="text1">
          Gramo (g)
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
        <label class="form-check-label" for="gridRadios2" id="text1">
          Miligramo (mg)
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
        <label class="form-check-label" for="gridRadios2" id="text1">
          Mililitro (ml)
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
        <label class="form-check-label" for="gridRadios2" id="text1">
          litro (L)
        </label>
      </div>
    </div>
                  <button type="submit" class="btn btn-danger btn-lg btn-block">Buscar</button>
                </form></div>
		</div>

		
		<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4" id="feo">
      <h2 id="title1">Instrucciones</h2>
      <li id="text1">
        1)  Coloca el nombre del medicamento en la casilla donde corresponde.
        </li><br>
        <li id="text1">
        2)  Coloca solo en numero la cantidad o medida metrica que buscas en la segunda casilla.
        </li><br>
        <li id="text1"> 3)  Selecciona la unidad metrica del medicamento.
        </li><br>
        <li id="text1"> 4)  Presiona  el  boton  Buscar  para  mostrar  los resultado ordenados.
        </li><br>
      
         </div>
   </div>
</div>
<br>
<div>
  <div class="container">
    <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="hola">
        <br><br>
        <div class="form-group">
                 
      </div>
    </div>
    
    
   </div>
</div>

    <div class="row justify-content-center pt-5 nt-5">
       <h2 id="seguir">Siguenocards en nuestras Redes Sociales</h2>
    </div>
   
    <br>
   
   <div class="container">
  <div class="card-deck">
  <div class="card">
    <img src="img/face.jpg" class="card-img-top" alt="...">
    <div class="card-body bg-dark">
      <h5 class="card-title text-white">¡Siguenos en Facebook!</h5>
    </div>
    <div class="bg-dark">
      <a href="#" class="btn btn-danger btn-lg btn-block">Ir a la pagina</a>
    </div>
  </div>
  
  <div class="card">
    <img src="img/instagram.png" class="card-img-top" alt="...">
    <div class="card-body bg-dark">
      <h5 class="card-title text-white bg-dark">¡Siguenos en Instagram!</h5>
    </div>
    <div class="bg-dark">
      <a href="#" class="btn btn-danger btn-lg btn-block">Ir a la pagina</a>
    </div>
  </div>
  
  <div class="card">
    <img src="img/tw.png" class="card-img-top" alt="...">
    <div class="card-body bg-dark">
      <h5 class="card-title text-white">¡Siguenos en Twitter!</h5>
    </div>
    <div class="bg-dark">
      <a href="#" class="btn btn-danger btn-lg btn-block">Ir a la pagina</a>
    </div>
  </div>

</div>
</div>

	  <!-- <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script> -->
</body>
</html>