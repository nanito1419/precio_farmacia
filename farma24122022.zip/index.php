<!DOCTYPE html">
<html lang="es">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="socor farmacia">
    <meta name="author" content="Giovanny Miquilena">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
    <link rel="shortcut icon" href="images/48855.png">
    <title>SOCOR FARMA v1.0</title>
    <link href="estilos/bootstrap.min.css" rel="stylesheet">
    <link href="estilos/signin.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <div class="container content">

   <!--<nav class="navbar navbar-fixed-top navbar-dark bg-dark ">-->
    <nav class="navbar navbar-dark bg-dark">
      <a class="navbar-brand" href="#">
       <img src="images/FVP1 SINF.png" width="150" height="90" class="d-inline-block align-top" alt="">
      </a>
       <ul class="nav navbar-nav navbar-right">
         <img src="images/socor.jpg" width="260" height="55" class="d-inline-block align-top" alt="">
       </ul>
  </nav>
</div>

<center><img src="images/logo.png" width="500" height="300" ></center>
<h1 class="form-signin-heading" align="center">SOCOR FARMA </h1>
<div class="container">
    <form class="form-signin" role="form" name="login_user" action="comprueba_login.php" method="post" />
    <h2 class="form-signin-heading">Inicio de sesión</h2>
        <input type="text" name='correo' class="form-control" placeholder="correo" required autofocus>
        <input type="password" name='pass' class="form-control" placeholder="contraseña" required>
        <div class="form-group mx-sm-4">
          <!-- goolge  <div class="g-recaptcha" data-sitekey="6LfBY68UAAAAAG6P6YMpYRH51b3TyYLwUKz9HMDY"></div> </div>-->
        <button class="btn btn-lg btn-primary btn-block" name="login" type="submit">Entrar</button>
        <!-- <b><a href="reset.php">resetear contraseña</a><b><br /><br /> -->
    </form>
	<center>SOCOR FARMA V1.0</center>
</div>

</body>
</html>