<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>

<style>

	h1{text-align:center;
	}
	
	table{
		width:25%;
		background-color:#FFC;
		border: 2px dotted #F00;
		margin:auto;}
		
		.izq{text-align:right;
		}
		
		.der{
			text-align:left;
		}
		
		td{
			text-align:center;
			padding:10px;
		}



</style>
</head>

<body>
	<?php/*
    session_start();
    if (!isset($_SESSION['login'])) {
      header("location:index.php");
    }*/

    ?>

<h1> INTRODUCE TUS DATOS DE REGISTRO</h1>

<form action="insertar_dato.php" method="post">

<table>
<tr style="">
<td class="izq">correo:</td><td class="der"><input type="text" name="correo"></td></tr>
<tr><td class="izq">Password:</td><td class="der"><input type="password" name="pass"></td></tr>
<tr><td class="izq">confirmar Password:</td><td class="der"><input type="password" name="passR"></td></tr>
<tr><td class="izq">cedula:</td><td class="der"><input type="text" name="cedula"></td></tr>
<tr><td class="izq">telefono:</td><td class="der"><input type="text" name="telefono"></td></tr>
<tr><td class="izq">pais</td><td class="der"><input type="text" name="pais"></td></tr>
<tr><td class="izq">estado:</td><td class="der"><input type="text" name="estado"></td></tr>
<tr><td class="izq">ciudad:</td><td class="der"><input type="text" name="ciudad"></td></tr>
<tr><td colspan="2"><input type="submit" name="enviar" value="REGISTRAR"></td></tr></table>

</body>
</html>