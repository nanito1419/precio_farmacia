<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>pagina de consutal CRUD</title>
</head>
<body BGCOLOR="#99aaff">

		<?php/*
    session_start();
    if (!isset($_SESSION['login'])) {
      header("location:login.php");
    }*/

    ?>

	<br><br><br><br><br><br><br><center>

<?php
	
	include("../conexion.php");

	//no la utilizare xq no tengo otra tabla para comprar
	function compara_estafador($correo, $cedula, $passcifrada, $telf)  //revisar si el que se esta registrando esta registrado como estafador
	{
		$conexion=conexion();
		$sql="SELECT correo_cuenta, telefono, cedula FROM estafadores WHERE correo_cuenta = :correo OR telefono = :telef OR cedula = :cel";
		$resultado=$conexion->prepare($sql);
		$resultado->execute(array(":correo"=>$correo, ":telef"=>$telf, ":cel"=>$cedula));
		$num_encontrado=$resultado->rowcount();

			if($num_encontrado>=1)
			{
				// un estafador intenta regisrarse		
				/*$celco="DATOS YA REGISTRADOS, INTENTE LOGUEARSE O INTRODUSCA NUEVOS DATOS.";// SI EL CORREO O EL CELU YA ESTAN REGISTRADOS
				header("location:index?cortel=$celco");*/
				echo " registro detectado como presunto estafador si crees que es un error o confunsion comunicate con soporte";
			}
			else
			{
				insertar_user ($correo, $cedula, $passcifrada, $telf);
			}			
	}
	


	function comparar_correo($correo, $passcifrada, $telf, $cedula, $pais, $estado, $ciudad) //comparar correo para no registrar 2 iguales
	{ 
		if(empty($correo) || empty($passcifrada) || empty($telf) || empty($pais) || empty($ciudad) || empty($cedula)) //si alguna esta vacia orror  (ver si quiere enviar datos vacios)
		{
			$orror=1;

			//echo "esta entrando aqui, xq esta vacio ";
			//header("location:formulario_registro.php?error=$orror");
			echo "falto una o mas casillas por rellenar";
		}
		else //ver si esta repetido
		{
			$conexion=conexion();
			$sql="SELECT correo, telefono, dni FROM login_farma WHERE correo = :correo OR telefono = :telef OR dni = :cel";
			$resultado=$conexion->prepare($sql);
			$resultado->execute(array(":correo"=>$correo, ":telef"=>$telf, ":cel"=>$cedula));
			$num_encontrado=$resultado->rowcount();

				if($num_encontrado>=1)
				{
					//PROPONER UNA FUNCION PARA VERIFICAR SI LA PERSONA QUE SE QUIERE INSCRIBIR ESTA EN LA BASE DE DATO COMO ESTAFADOR		
					/*$celco="DATOS YA REGISTRADOS, INTENTE LOGUEARSE O INTRODUSCA NUEVOS DATOS.";// SI EL CORREO O EL CELU YA ESTAN REGISTRADOS
					header("location:index?cortel=$celco");*/
					echo "usuario ya registrado";
				}
				else
				{
					insertar_user ($correo, $cedula, $passcifrada, $telf, $pais, $estado, $ciudad);
				}			

		}
	}

	function insertar_user ($correo, $cedula, $passcifrada, $telf, $pais, $estado, $ciudad)
	{
		$conexion=conexion();		
		$sql="INSERT INTO login_farma (correo, telefono, dni, password, pais, estado, ciudad) VALUES (:corr, :telef, :ceducli, :pass, :pais, :estado, :ciudad)";		
		$resultado=$conexion->prepare($sql);
		$resultado->execute(array(':corr'=>$correo, ':telef'=>$telf, ':ceducli'=>$cedula, ':pass'=>$passcifrada, ':pais'=>$pais, ':estado'=>$estado, ':ciudad'=>$ciudad));
		
		//$resulatado->closeCursor();
		// header o mensaje de ya registardo

		echo "usuario registrado con existo";


	}

	$correo=htmlentities(addslashes($_POST["correo"]));
	$telf=htmlentities(addslashes($_POST["telefono"]));
	$cedula=htmlentities(addslashes($_POST["cedula"]));
	$pais=htmlentities(addslashes($_POST["pais"]));
	$estado=htmlentities(addslashes($_POST["estado"]));
	$ciudad=htmlentities(addslashes($_POST["ciudad"]));
	$password=$_POST["pass"];// paas original
	$passwordR=$_POST["passR"];  //pass  de confirmacion		
	


	IF ($password==$passwordR)  //conparacion de pass de confirmacion
	{
		$passcifrada=password_hash($password,PASSWORD_DEFAULT); // cifrando la password


		comparar_correo($correo, $passcifrada, $telf, $cedula, $pais, $estado, $ciudad);
	
	
		//header
	}
	ELSE
	{
		$A="LA PASSWORD NO COINCIDEN, INTENTA DE NUEVO ";
		header("LOCATION:formulario_registro.php?B=$A");
	}

?>

<a href="index.php"> <INPUT TYPE="button" id="regre" name="regre" VALUE="volver"></a> </center>
</body>
</html>