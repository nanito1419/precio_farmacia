<?php

function farma_Farmamedica_Coro($busqueda) {
				$base=conexion();
				if(empty($busqueda)){
					header("location:dashboard.php");
				}else{
				try{
					$sql="SELECT * From f_farmamedica_coro WHERE nombre_comercial LIKE ? or compuesto_activo LIKE ? ORDER BY precio ASC";

					$resultado=$base->prepare($sql);

					$resultado->execute(array("%" . $busqueda . "%", "%" . $busqueda . "%"));

					$encontrado=$resultado->rowcount(); // esta cuenta si hubo resultado encontrado o no?> 


					<?php if ($encontrado!=0) 
					{

						echo "<div class='container'> " . "<div class='row'>" . "<div class='col-xs-12 col-sm-12 col-md-12 col-lg-12' id='hola'><br>" . "<table class='table table-dark table-striped'>" . "<thead id='text1'>" . "<tr><th scope='col'>Farmacia</th><th scope='col'>" . "Medicamento</th><th scope='col'>" . "Precio</th><th scope='col'>" . "Existencia</th><th scope='col'>" . "Direccion</th><th scope='col'>" . "Actulizacion</th></tr></thead>" ;?>

					<?php

						while ($registro=$resultado->fetch(PDO::FETCH_ASSOC)) 
						{

							//header("location:encontrado.php");
						echo "<tbody><tr><th scope='row'>" . "Farmacia Farmamedica Coro" . "</th>" . "<td>" .  $registro['nombre_comercial'] . "</td>" .  "<td>" . $registro['precio'] ."</td> <td>" . $registro['existencia'] . "</td><td>" . "<a target='_blank'  href='http://bit.ly/3jeJxKy'>GOOGLE MAP</a>" . "</td><td>" . $registro['fecha_actualizacion'] . "</td>" ;
						
						}

						farma_los_medanos($busqueda);?> </table><?php

						$resultado->closecursor();
						
					}
					else
					{
						echo "<center> <h2>no encontrado</h2> </center>" ;
						//header("location:noencontrado.php");
					}

					

					}catch(Exception $e){

						die ('error bruto' . $e->Getmessage());
					} finally{$base=null;}
				}//cierre del else

	}

	function farma_los_medanos($busqueda) {
				$base=conexion();
				if(empty($busqueda)){
					header("location:dashboard.php");
				}else{
				try{
					$sql="SELECT * From f_los_medanos  WHERE nombre_comercial LIKE ? or compuesto_activo LIKE ? ORDER BY precio ASC";

					$resultado=$base->prepare($sql);

					$resultado->execute(array("%" . $busqueda . "%", "%" . $busqueda . "%" ));

					$encontrado=$resultado->rowcount(); // esta cuenta si hubo resultado encontrado o no?> 


					<?php if ($encontrado!=0) 
					{

						echo "</tr><tbody class='table-primary'> <tr> <td> <td></td><td></td><td></td><td></td><td></td></td></tr>" ;?>

					<?php

						while ($registro=$resultado->fetch(PDO::FETCH_ASSOC)) 
						{

							//header("location:encontrado.php");
						echo "<tbody ><tr><th scope='row'>" . "Farmacia Los Medanos" . "</th>" . "<td>" .  $registro['nombre_comercial'] . "</td>" .  "<td>" . $registro['precio'] ."</td> <td>" . $registro['existencia'] . "</td><td>" . "<a target='_blank'  href='http://bit.ly/3jeJxKy'>GOOGLE MAP</a>" . "</td><td>" . $registro['fecha_actualizacion'] . "</td></tr>" ;
						
						}?> </table><?php

						$resultado->closecursor();
						
					}
					else
					{
						echo "no encontrado" ;
						//header("location:noencontrado.php");
					}

					

					}catch(Exception $e){

						die ('error bruto' . $e->Getmessage());
					} finally{$base=null;}
				}//cierre del else

	}


?>