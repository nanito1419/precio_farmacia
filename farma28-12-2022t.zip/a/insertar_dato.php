<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>pagina de consutal CRUD</title>
</head>
<body BGCOLOR="#99aaff">

		<?php/*
    session_start();
    if (!isset($_SESSION['login'])) {
      header("location:login.php");
    }*/

    ?>

	<br><br><br><br><br><br><br><center>

<?php
	
	include("../conexion.php");

////  2   ////
	//buscar el ide de referencia en los regisros, sino el id_de referencia sera 0  
	function ver_referencia($correo, $passcifrada, $telf, $cedula, $corefe, $estado, $municipio)
	{

		$conexion=conexion();
		$sql="SELECT id_user, correo FROM login_farma WHERE id_user = :coref";
		$resultado=$conexion->prepare($sql);
		$resultado->execute(array(":coref"=>$corefe));
		$num_encontrado=$resultado->rowcount();

			if($num_encontrado!=0)
			{
				while ($registro=$resultado->fetch(PDO::FETCH_ASSOC)) 
				{
					//guardo el correo para poder ubicar el referido y sumarlo
					$correfe=$registro["correo"];
					//con referido
					insertar_user_con ($correo, $passcifrada, $telf, $cedula, $corefe, $estado, $municipio, $correfe);
				}
			}

			else
			{
					//sin referido
				$corefe=0;
				insertar_user ($correo, $passcifrada, $telf, $cedula, $corefe, $estado, $municipio);
			}


	}
		//no la estoy utilizando ya que realice corrido el codigo en la function insertar_user_con
	function actualizar ($suma_refe, $correo)
		{
		$sql="UPDATE saldo_cliente SET referidos = :suma_ref WHERE saldo_cliente = :cor";		
		$resultado=$conexion->prepare($sql);
		$resultado->execute(array(':cor'=>$correo, 'suma_ref'=>$suma_refe));

		echo "$suma_refe" . " <br> " . $correo;


		}

		

//////////////////////////    1     //////////////////////////////////
	function comparar_correo($correo, $passcifrada, $telf, $cedula, $corefe, $estado, $municipio) //comparar correo para no registrar 2 iguales
	{ 
		if(empty($correo) || empty($passcifrada) || empty($telf) || empty($estado) || empty($municipio) || empty($cedula)) //si alguna esta vacia orror  (ver si quiere enviar datos vacios)
		{
			$orror=1;

			//echo "esta entrando aqui, xq esta vacio ";
			//header("location:formulario_registro.php?error=$orror");
			echo "falto una o mas casillas por rellenar";

			header("LOCATION:../a/registro_user.php");
		}
		else //ver si esta repetido
		{
			$conexion=conexion();
			$sql="SELECT correo, telefono, dni FROM login_farma WHERE correo = :correo OR telefono = :telef OR dni = :cel";
			$resultado=$conexion->prepare($sql);
			$resultado->execute(array(":correo"=>$correo, ":telef"=>$telf, ":cel"=>$cedula));
			$num_encontrado=$resultado->rowcount();

				if($num_encontrado>=1)
				{
					//PROPONER UNA FUNCION PARA VERIFICAR SI LA PERSONA QUE SE QUIERE INSCRIBIR ESTA EN LA BASE DE DATO COMO ESTAFADOR		
					/*$celco="DATOS YA REGISTRADOS, INTENTE LOGUEARSE O INTRODUSCA NUEVOS DATOS.";// SI EL CORREO O EL CELU YA ESTAN REGISTRADOS
					header("location:index?cortel=$celco");*/
					echo "<H2>Algunos de los datos que esta utilizando estan ya registrado</h>";

					header("LOCATION:../a/registro_user.php");
				}
				else
				{
					ver_referencia($correo, $passcifrada, $telf, $cedula, $corefe, $estado, $municipio);
				}			

		}
	}

				//registro con referencia
			function insertar_user_con ($correo, $passcifrada, $telf, $cedula, $corefe, $estado, $municipio, $correfe)
	{
			$conexion=conexion();
			$t=5;
			//insertar en la tabla login_farma
			$sql="INSERT INTO login_farma (correo, telefono, dni, password, estado, municipio, id_refe, ticker) VALUES (:corr, :telefe, :ceducli, :pass, :estadoc, :ciudad, :id_ref, :tick)";		
			$resultado=$conexion->prepare($sql);
			$resultado->execute(array(':corr'=>$correo, ':telefe'=>$telf, ':ceducli'=>$cedula, ':pass'=>$passcifrada, ':estadoc'=>$estado, ':ciudad'=>$municipio, ':id_ref'=>$corefe, ':tick'=>$t)); 
			$resultado->closeCursor();
			$conexion1=conexion();
			$sql="SELECT referidos From saldo_cliente WHERE correo_user = :coruse ";
			$resultado=$conexion1->prepare($sql);
			$resultado->execute(array(':coruse'=>$correfe));
			while ($registro=$resultado->fetch(PDO::FETCH_ASSOC)) 
			{
				$conexion2=conexion();
				$suma_refe=$registro['referidos']+1;
				$sql="UPDATE saldo_cliente SET referidos = :sumauno WHERE correo_user = :correo_p";		
				$resultado2=$conexion2->prepare($sql);
				$resultado2->execute(array(':sumauno'=>$suma_refe, ':correo_p'=>$correfe));
				echo "usuario registrado con existo:";
			}	
			//insertar en la tabla
			//$resulatado->closeCursor();
			// header o mensaje de ya registardo
	}

		//registro sin referencia
	function insertar_user ($correo, $passcifrada, $telf, $cedula, $corefe, $estado, $municipio)
	{
		$conexion=conexion();
		$t=5;
		//insertar en la tabla login_farma
		$sql="INSERT INTO login_farma (correo, telefono, dni, password, estado, municipio, id_refe, ticker) VALUES (:corr, :telefe, :ceducli, :pass, :estadoc, :ciudad, :id_ref, :tick)";		
		$resultado=$conexion->prepare($sql);
		$resultado->execute(array(':corr'=>$correo, ':telefe'=>$telf, ':ceducli'=>$cedula, ':pass'=>$passcifrada, ':estadoc'=>$estado, ':ciudad'=>$municipio, ':id_ref'=>$corefe, ':tick'=>$t));

		//insertar en la tabla saldo_cliente
		$suma_refe=0;
		$sql="INSERT INTO saldo_cliente (correo_user, referidos) VALUES (:id_user, :suma_ref)";		
		$resultado=$conexion->prepare($sql);
		$resultado->execute(array(':id_user'=>$correo, 'suma_ref'=>$suma_refe));


		//$resulatado->closeCursor();
		// header o mensaje de ya registardo

		echo "<h2>usuario registrado con existo <br> ya puedes loguearte!! </h2>";


	}

	$correo=htmlentities(addslashes($_POST["correo"]));
	$telf=htmlentities(addslashes($_POST["telefono"]));
	$cedula=htmlentities(addslashes($_POST["cedula"]));
	$corefe=htmlentities(addslashes($_POST["corefe"]));
	$estado=htmlentities(addslashes($_POST["estado"]));
	$municipio=htmlentities(addslashes($_POST["municipio"]));
	$password=htmlentities(addslashes($_POST["pass"]));// paas original
	$passwordR=htmlentities(addslashes($_POST["passR"]));  //pass  de confirmacion		
	


	IF ($password==$passwordR)  //conparacion de pass de confirmacion
	{
		$passcifrada=password_hash($password,PASSWORD_DEFAULT); // cifrando la password


		comparar_correo($correo, $passcifrada, $telf, $cedula, $corefe, $estado, $municipio);
	
	
		//header
	}
	ELSE
	{
		/*$A="LA PASSWORD NO COINCIDEN, INTENTA DE NUEVO ";
		header("LOCATION:formulario_registro.php?B=$A");*/

		header("LOCATION:../a/registro_user.php");

	}


?>

<a href="http://localhost/SISTEMA%20PRECIO/"> <INPUT TYPE="button" id="regre" name="regre" VALUE="volver a la pagina principal"></a> </center>
</body>
</html>