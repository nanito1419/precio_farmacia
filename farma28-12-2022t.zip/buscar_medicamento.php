<DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>SOCOR FARMA v1.0</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
	<link rel="stylesheet" type="text/css" href="estilos/22.css">
	<link rel="shortcut icon" href="images/48855.png">
</head>
<body>

	<nav class="navbar navbar-fixed-top navbar-dark bg-dark ">
    <a class="navbar-brand" href="#">
      <img src="images/FVP1 SINF.png" width="90" height="55" class="d-inline-block align-top" alt="">
      <img src="images/socor.jpg" width="250" height="55" class="d-inline-block align-top" alt="">
      
    </a>
      <ul class="nav navbar-nav navbar-right">
         <a href="cierre.php"><button class="btn btn-danger">Cerrar sesion</button></a>
     </ul>
   </nav>

   <br><br><br><br><br>
<center><a href="dashboard.php"><button class="btn btn-danger">VOLVER AL BUSCADOR</button></a></center>
  <?php
    session_start();
    if (!isset($_SESSION['login'])) {
      header("location:index.php");
    }

  ?>


<?php

include("conexion.php");
include("buscador_farma.php");


$busqueda = $_GET["nombre_medicamento"];

		farma_Farmamedica_Coro($busqueda);




?>

<center><a href="dashboard.php"><button class="btn btn-danger">VOLVER AL BUSCADOR</button></a></center>



        </body>
</html>