
 <?php 
    session_start();
    if (!isset($_SESSION['login'])) {
      header("location:index.php");
    }
 ?>
<?php
	
	require("captchar_validator.php");

	$login1=htmlentities(addslashes($_POST["correo"]));
	
	$password1=htmlentities(addslashes($_POST["pass"]));

	/*limpiar_cadena1($login1);

	limpiar_cadena2($password1); ver para evitar inyeccion*/

	
	//$captcha=$_POST['g-recaptcha-response'];
	
		//include("conexion.php");	
	 //validator($login1, $password1, $captcha); //esta funcioon la llamo ccuando coloque captchar-
	comprueba_login($login1, $password1);

?>