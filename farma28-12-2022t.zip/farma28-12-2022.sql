-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 28-12-2022 a las 13:19:37
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `farma`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `f_farmamedica_coro`
--

CREATE TABLE `f_farmamedica_coro` (
  `municipio` varchar(10) DEFAULT NULL,
  `nombre_comercial` varchar(40) DEFAULT NULL,
  `compuesto_activo` varchar(25) DEFAULT NULL,
  `cantidad` varchar(10) NOT NULL,
  `clasificacion` varchar(25) DEFAULT NULL,
  `precio` varchar(6) DEFAULT NULL,
  `existencia` varchar(6) DEFAULT NULL,
  `lote` varchar(10) DEFAULT NULL,
  `fecha_actualizacion` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `f_farmamedica_coro`
--

INSERT INTO `f_farmamedica_coro` (`municipio`, `nombre_comercial`, `compuesto_activo`, `cantidad`, `clasificacion`, `precio`, `existencia`, `lote`, `fecha_actualizacion`) VALUES
('1', 'acetaminofen', 'paracetamol', '10mg', 'analgesico', '1.5', '10', '504411', '20/12/2022'),
(NULL, 'table de acetaminofen', 'paracetamol', '100gm', 'analgesico', '2', '15', '550011', '20/12/2022'),
(NULL, 'tubo acetaminofen liquido on paracetamol', 'paracetamol', '500gm', 'analgesico', '5', '20', '778899', '21/12/2022'),
('miranda', 'acetapan', 'paracetamol', '30', 'analgesico', '0.9', '28', '224455', '27/12/2022'),
('miranda', 'pacetamol', 'acetamenofen', '500gm', 'analgesico', '1.3', '40', '778899', '27/12/2022');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `f_los_medanos`
--

CREATE TABLE `f_los_medanos` (
  `municipio` varchar(10) DEFAULT NULL,
  `nombre_comercial` varchar(40) DEFAULT NULL,
  `compuesto_activo` varchar(25) DEFAULT NULL,
  `cantidad` varchar(10) NOT NULL,
  `clasificacion` varchar(25) DEFAULT NULL,
  `precio` varchar(6) DEFAULT NULL,
  `existencia` varchar(6) DEFAULT NULL,
  `lote` varchar(10) DEFAULT NULL,
  `fecha_actualizacion` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `f_los_medanos`
--

INSERT INTO `f_los_medanos` (`municipio`, `nombre_comercial`, `compuesto_activo`, `cantidad`, `clasificacion`, `precio`, `existencia`, `lote`, `fecha_actualizacion`) VALUES
('', 'ace', 'paracetamol', '200mg', 'analgesico', '3', '8', '504411', '22/12/2022'),
('', 'inyecc paracetamol', 'acetamenofen', '500gm', 'analgesico', '5', '20', NULL, '22/12/2022'),
('miranda', 'acetafono', 'paracetamol', '200mg', 'analgesico', '1', '45', '504411', '27/12/2022');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login_farma`
--

CREATE TABLE `login_farma` (
  `id_user` int(12) NOT NULL,
  `correo` varchar(35) NOT NULL,
  `telefono` varchar(18) NOT NULL,
  `dni` varchar(16) NOT NULL,
  `password` varchar(100) NOT NULL,
  `estado` varchar(25) NOT NULL,
  `municipio` varchar(25) NOT NULL,
  `id_refe` int(6) NOT NULL,
  `confirmado` varchar(2) NOT NULL DEFAULT 'si',
  `ticker` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `login_farma`
--

INSERT INTO `login_farma` (`id_user`, `correo`, `telefono`, `dni`, `password`, `estado`, `municipio`, `id_refe`, `confirmado`, `ticker`) VALUES
(1, 'q', 'q', 'q', '$2y$10$PtKz8Pz/mSNcWn4JpS1UOeT/eqP0N2C6gfjg/JZY9zc265rDlSjcy', 'q', 'q', 0, 'no', 0),
(2, 's', 's', 's', '$2y$10$OgjXxESc7Cf9rnXf17xiR.F065NQFWm2rGch0tEfqgNvHGsovF7vO', 's', 's', 0, 'no', 5),
(19, 'y', 'y', 'y', '$2y$10$YwFC/b20RHqBy14bQUclSOdfIkbBJpQfu8zftovFUdMuQujN5tjxG', 'y', 'y', 0, 'si', 5),
(27, 'u', 'u', 'u', '$2y$10$NkIQOqL2maVGp0gDUoRoJeQuebUnRTEqYYRif1YyaQmhTei3GLxNK', 'u', 'u', 19, 'si', 5),
(28, 'i', 'i', 'i', '$2y$10$ZTiAXQuMWrsaJTGgP6vTIO1y6dNCG2xIgJHbpTdMFRy22I9IMAPhC', 'i', 'i', 27, 'si', 5),
(29, 'o', 'o', 'o', '$2y$10$6SCLdlou5BU.X.mNknVDmeaNx3g3Pb6MD7L5n0Y.PLPWMuICj70hS', 'o', 'o', 0, 'si', 5),
(30, 'p', 'p', 'p', '$2y$10$8FzP84eyxLXPCgN3byfNkOzz4FQlhsxDyOpDqFopWc/4LAEziWnKK', 'p', 'p', 29, 'si', 5),
(32, 'l', 'l', 'l', '$2y$10$Z8SQW7DVuDseiUiejVXTd.mGB.cycR1NwVetyvMXQFYa95E5WSTi6', 'l', 'l', 29, 'si', 5),
(33, 'a', 'a', 'a', '$2y$10$nncvHkhLuPwKNvyVcVsSYuhyQacnqTm5/Bl7eTQ.WXdnhRVpwUoYu', 'o', 'y', 29, 'si', 5),
(34, 'd', 'd', 'd', '$2y$10$eDYP7uV6hjsyPCCTSzdzJOKcgGyXE1nptJZ4cu2E4P52iy02qrbrO', 'd', 'd', 0, 'si', 5),
(35, 'f', 'f', 'f', '$2y$10$uomZpn.cP8MRZ..vqr2XfuVIaaMVvYNNMBhnspBpg8tff5k7QN/oW', 'f', 'f', 0, 'si', 5),
(36, 'g', 'g', 'g', '$2y$10$WFwFKNwNbt3MX7XQYV7ZkeRpCArPPINYHwyPrf0VI6VmRq2MyLSAe', 'g', 'g', 0, 'si', 5),
(37, 'z', 'z', 'z', '$2y$10$tfHrhU113DmJWABh9ayUVelOOvmOTx6TzGOfmCjqLdgpwelzAsTwq', 'z', 'z', 29, 'si', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `saldo_cliente`
--

CREATE TABLE `saldo_cliente` (
  `correo_user` varchar(50) NOT NULL,
  `referidos` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `saldo_cliente`
--

INSERT INTO `saldo_cliente` (`correo_user`, `referidos`) VALUES
('d', 0),
('f', 0),
('g', 0),
('o', 4);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `login_farma`
--
ALTER TABLE `login_farma`
  ADD PRIMARY KEY (`id_user`);

--
-- Indices de la tabla `saldo_cliente`
--
ALTER TABLE `saldo_cliente`
  ADD UNIQUE KEY `correo_user` (`correo_user`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `login_farma`
--
ALTER TABLE `login_farma`
  MODIFY `id_user` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
